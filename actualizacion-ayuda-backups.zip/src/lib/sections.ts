// ═══════════════════════════════════════════════════════════════════
// SECCIONES DEL SISTEMA
// Las usan el menú de arriba y la pantalla de inicio (/admin).
// adminOnly → para entrar se pide usuario y contraseña de un administrador
//             (aunque la compu ya tenga una sesión abierta).
// owner     → solo el DUEÑO, con su usuario y contraseña únicos (Caja, Contabilidad, Usuarios).
// ═══════════════════════════════════════════════════════════════════

export type Role = "admin" | "vendedor";

export type Section = {
  href: string;
  label: string;
  desc: string;
  icon: keyof typeof ICONS;
  color: string;        // color del ícono
  adminOnly?: boolean;
  owner?: boolean;
  soon?: boolean;
  match?: string[];     // otras rutas que pertenecen a esta sección
  noTab?: boolean;      // no va en el menú de arriba (se llega por un botón propio), sí en el inicio
};

export const SECTIONS: Section[] = [
  { href: "/admin/ventas", label: "Ventas", desc: "Vender y cobrar", icon: "cart", color: "#0891b2" },
  { href: "/admin/caja", label: "Caja", desc: "Abrir, cerrar y resumen del día", icon: "register", color: "#059669", adminOnly: true, owner: true },
  { href: "/admin/articulos", label: "Artículos", desc: "Precios, stock y fotos", icon: "box", color: "#d97706", match: ["/admin/productos", "/admin/sin-foto"] },
  { href: "/admin/clientes", label: "Clientes", desc: "Fichas e historial", icon: "users", color: "#7c3aed" },
  { href: "/admin/proveedores", label: "Proveedores", desc: "Contactos y pedidos por WhatsApp", icon: "truck", color: "#4f46e5", match: ["/admin/reposicion"] },
  { href: "/admin/contabilidad", label: "Contabilidad", desc: "Ganancias, gastos y cierres", icon: "chart", color: "#db2777", adminOnly: true, owner: true },
  { href: "/admin/pedido-saphirus", label: "Saphirus", desc: "Armar el pedido de aromas", icon: "drop", color: "#db2777" },
  { href: "/admin/pedidos", label: "Tienda web", desc: "Pedidos de la página", icon: "globe", color: "#0284c7", adminOnly: true, match: ["/admin/resumen"] },
  { href: "/admin/compras", label: "Compras", desc: "Cargar facturas por foto", icon: "camera", color: "#0d9488", adminOnly: true, match: ["/admin/carga-stock"] },
  { href: "/admin/usuarios", label: "Usuarios", desc: "Vendedores y permisos", icon: "lock", color: "#475569", adminOnly: true, owner: true },
  { href: "/admin/ayuda", label: "Ayuda", desc: "Guía de uso y atajos", icon: "help", color: "#0e7490", noTab: true },
];

// Todos ven todas las secciones; las de administrador muestran un candado
export const visibleSections = (_role?: Role | null) => SECTIONS;

/** Rutas donde el acceso de administrador sigue activo (al salir de ellas se bloquea) */
export const keepsAdmin = (path: string | null | undefined) =>
  !!path && (!!sectionOf(path)?.adminOnly || path.startsWith("/admin/articulos") || path.startsWith("/admin/sin-foto"));

export const sectionOf = (path: string | null | undefined): Section | null => {
  if (!path) return null;
  return SECTIONS.find((s) => path.startsWith(s.href) || s.match?.some((m) => path.startsWith(m))) || null;
};

// Íconos (trazos SVG de 24×24)
export const ICONS = {
  cart: "M3 3h2l2.4 12.2a2 2 0 0 0 2 1.6h8.8a2 2 0 0 0 2-1.5L22 7H6 M9 21h.01 M18 21h.01",
  register: "M4 10h16v10H4z M7 10V5h10v5 M8 14h2 M8 17h2 M13 14h3 M13 17h3 M9 7h6",
  box: "M21 8l-9-5-9 5 9 5 9-5z M3 8v8l9 5 9-5V8 M12 13v8",
  users: "M9 11a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4z M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6 M16 4.5a3 3 0 0 1 0 6 M21 20c0-2.6-1.6-4.8-4-5.6",
  truck: "M3 6h11v10H3z M14 10h4l3 3v3h-7 M7 20a1.8 1.8 0 1 0 0-3.6A1.8 1.8 0 0 0 7 20z M17 20a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6z",
  chart: "M3 3v18h18 M7 15l4-4 3 3 6-7 M16 7h4v4",
  globe: "M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z M2 12h20 M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z",
  camera: "M3 8a2 2 0 0 1 2-2h2l2-2h6l2 2h2a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z M12 16.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z",
  lock: "M4 11h16v10H4z M8 11V7a4 4 0 0 1 8 0v4",
  drop: "M12 3c3.5 4.2 6 7.6 6 10.8A6 6 0 0 1 6 13.8C6 10.6 8.5 7.2 12 3z M9.5 14.5a2.5 2.5 0 0 0 2.5 2.5",
  home: "M3 11l9-8 9 8 M5 10v10h14V10",
  help: "M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z M9.1 9a3 3 0 0 1 5.8 1c0 2-3 2.5-3 4.5 M12 17.5h.01",
} as const;
